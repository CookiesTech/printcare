<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-07 07:41:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 07:41:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 07:41:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 07:41:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 07:41:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 07:41:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\dashboard\controllers\Dashboard.php 17
ERROR - 2022-08-07 07:41:55 --> 404 Page Not Found: /index
ERROR - 2022-08-07 07:42:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 07:42:23 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 07:42:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 07:42:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 07:42:23 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 07:42:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 07:42:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 07:42:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 07:42:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 07:42:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 07:42:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 07:42:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 07:42:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 07:42:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 07:42:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 07:42:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 07:42:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 07:42:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 07:42:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 07:42:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 07:42:33 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 07:42:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 07:42:33 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 07:42:33 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 07:42:33 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:06:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:06:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:06:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:06:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:06:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:06:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:06:40 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:06:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:06:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:06:40 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:06:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:06:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:06:40 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:06:40 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:06:40 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:07:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:07:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:07:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:07:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:07:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:07:48 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:07:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:07:48 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:07:48 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:07:48 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:09:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:09:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:09:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:09:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:09:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:09:24 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:09:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:09:24 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:09:24 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:09:24 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:09:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:09:45 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:09:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:09:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:09:45 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:09:45 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:09:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:09:45 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:09:45 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:09:45 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:10:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:10:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:10:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:10:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:10:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:10:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:10:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:10:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:10:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:10:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:11:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:11:14 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:11:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:11:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:11:14 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:11:14 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:11:14 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:12:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:12:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:12:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:12:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:12:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:12:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:12:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:14:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:14:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:14:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:14:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:14:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:14:03 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:14:03 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:14:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:14:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:14:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:14:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:14:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:14:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:14:21 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:14:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:14:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:14:21 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:14:21 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:14:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:14:21 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:14:21 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:14:21 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:17:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:17:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:17:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:17:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:17:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:17:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:17:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:17:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:17:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:17:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:17:26 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:17:26 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:17:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:17:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:17:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:17:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:17:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:17:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:17:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:17:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:17:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:17:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:17:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:17:32 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:17:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:17:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:17:32 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:17:32 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:17:32 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:18:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:18:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:18:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:18:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:18:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:18:35 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:18:35 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:19:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:19:25 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:19:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:19:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:19:25 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:19:25 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:19:25 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:19:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:19:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:19:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:19:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:19:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:19:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:19:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:19:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:19:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:19:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:19:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:19:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:28:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:28:47 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:28:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:28:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:28:47 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:30:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:30:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:30:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:30:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:30:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:30:27 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:30:27 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:30:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:30:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:30:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:30:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:30:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:30:30 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:30:30 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:30:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:30:34 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:30:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:30:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:30:34 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:31:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:31:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:31:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:31:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:31:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:35:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:35:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:35:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:35:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:35:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:35:29 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:35:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:35:29 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:35:29 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:35:29 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Attempt to read property "sub_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Attempt to read property "sub_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Attempt to read property "supp_discount_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Attempt to read property "supp_discount_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Attempt to read property "gst_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Attempt to read property "gst_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Attempt to read property "grand_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Attempt to read property "grand_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-08-07 08:39:19 --> Severity: Warning --> Undefined variable $supplier_html C:\xampp\htdocs\printcare\application\modules\purchase_order\views\script_purchase_order.php 83
ERROR - 2022-08-07 08:39:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:39:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:39:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:39:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:39:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:39:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:39:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:39:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:39:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:39:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\printcare\application\modules\product\controllers\Product.php 226
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\printcare\system\libraries\Parser.php 144
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 19
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 19
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Attempt to read property "ref_category_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 19
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 29
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 29
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Attempt to read property "product_name" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 29
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 37
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 37
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Attempt to read property "sku" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 37
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 46
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 46
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Attempt to read property "unit" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 46
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 57
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 57
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Attempt to read property "ref_stock_room_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 57
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 70
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 70
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Attempt to read property "ref_stock_slot_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 70
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 92
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 92
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Attempt to read property "ref_quantity_type_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 92
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 115
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 115
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Attempt to read property "ref_gst_type_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 115
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 145
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 145
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Attempt to read property "featured_product" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 145
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 153
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 153
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Attempt to read property "display_homepage" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 153
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 164
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 164
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Attempt to read property "ref_star_rating_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 164
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 187
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 187
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> Attempt to read property "product_image_file" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 187
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:39:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:40:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:40:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:40:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:40:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:40:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:40:15 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:40:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:40:15 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:40:15 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:40:15 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:41:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:41:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:41:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:41:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:41:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:41:31 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:41:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:41:31 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-07 08:41:31 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:41:31 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:41:35 --> 404 Page Not Found: /index
ERROR - 2022-08-07 08:41:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:41:39 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:41:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:41:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:41:39 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:41:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:41:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:41:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:41:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:41:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:41:42 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:41:42 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-07 08:41:48 --> 404 Page Not Found: /index
ERROR - 2022-08-07 08:41:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:41:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:41:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:41:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:41:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:41:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:41:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:41:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:41:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:41:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:50:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:50:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:50:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:50:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:50:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:52:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:52:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:52:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:52:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:52:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:52:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:52:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:52:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:52:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:52:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:52:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:52:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:52:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:52:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:52:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:52:37 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-08-07 08:52:37 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-08-07 08:55:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:55:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:55:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:55:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:55:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:55:28 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-08-07 08:55:28 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-08-07 08:55:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-08-07 08:55:29 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-08-07 08:57:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:57:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:57:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:57:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:57:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:57:50 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-08-07 08:57:50 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-08-07 08:58:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:58:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:58:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:58:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:58:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:58:50 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-08-07 08:58:50 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-08-07 08:58:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:58:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:58:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:58:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:58:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:58:52 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-08-07 08:58:52 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-08-07 08:59:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 08:59:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 08:59:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 08:59:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 08:59:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 08:59:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:00:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:00:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:00:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:00:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:00:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:00:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:02:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:02:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:02:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:02:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:02:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:02:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:04:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:04:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:04:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:04:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:04:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:04:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:05:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:05:13 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:05:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:05:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:05:13 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:05:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:05:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:05:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:05:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:05:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:05:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:05:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:06:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:06:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:06:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:06:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:06:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:06:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:07:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:07:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:07:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:07:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:07:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:07:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:08:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:08:23 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:08:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:08:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:08:23 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:08:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:08:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:08:44 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:08:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:08:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:08:44 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:08:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:19:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:19:44 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:19:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:19:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:19:44 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:19:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:20:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:20:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:20:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:20:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:20:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:20:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:20:34 --> 404 Page Not Found: /index
ERROR - 2022-08-07 09:20:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:20:36 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:20:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:20:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:20:36 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:20:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:20:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:20:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:20:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:20:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:20:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:20:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:29:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:29:13 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:29:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:29:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:29:13 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:29:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:30:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:30:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:30:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:30:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:30:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:30:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:30:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:30:47 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:30:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:30:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:30:47 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:30:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:30:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:30:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:30:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:30:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:30:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:30:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:32:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:32:40 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:32:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:32:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:32:40 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:32:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:38:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:38:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:38:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:38:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:38:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:38:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:38:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:38:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:38:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:38:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:38:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:38:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:39:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:39:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:39:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:39:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:39:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:39:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:39:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:39:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:39:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:39:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:39:34 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:40:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:40:25 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:40:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:40:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:40:25 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:40:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:41:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:41:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:41:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:41:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:41:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:41:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-08-07 09:41:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-07 09:41:49 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-07 09:41:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-07 09:41:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-07 09:41:49 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-07 09:41:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
