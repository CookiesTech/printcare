<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-16 09:47:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 09:47:34 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 09:47:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 09:47:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 09:47:34 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 09:47:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 09:47:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 09:47:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 09:47:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 09:47:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 09:47:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 09:47:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 09:47:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 09:47:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 09:47:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 09:59:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 09:59:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 09:59:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 09:59:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 09:59:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 11:39:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 11:39:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 11:39:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 11:39:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 11:39:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 11:39:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 11:39:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 11:39:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 11:39:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 11:39:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:24:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:24:34 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:24:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:24:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:24:34 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:24:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\dashboard\controllers\Dashboard.php 17
ERROR - 2022-06-16 12:24:34 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:25:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:25:04 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:25:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:25:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:25:04 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:25:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:25:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:25:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:25:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:25:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:25:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:25:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:25:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:25:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:25:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:25:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:25:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:25:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:25:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:25:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:25:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:25:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:25:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:25:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:25:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:25:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:25:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:25:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:25:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:25:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:25:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:25:17 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:25:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:25:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:25:17 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:25:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:25:17 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:25:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:25:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:25:17 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:25:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:25:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:25:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:25:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:25:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:25:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:25:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:25:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:25:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:25:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:25:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:25:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:25:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:25:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:25:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:25:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:25:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:25:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:25:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:25:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:44:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:44:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:44:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:44:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:44:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:44:26 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:44:26 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:44:26 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:44:26 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:44:26 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:44:26 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:44:27 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:47:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:47:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:47:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:47:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:47:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:47:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:47:49 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:47:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:47:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:47:49 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:47:50 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:47:50 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:47:50 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:47:50 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:47:50 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:47:50 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:47:51 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:47:51 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:47:51 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:47:51 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:47:51 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:47:51 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:49:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:49:20 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:49:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:49:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:49:20 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:49:21 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:49:21 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:49:21 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:49:21 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:49:21 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:49:21 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:50:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:50:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:50:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:50:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:50:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:50:55 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:50:55 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:50:55 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:50:55 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:50:55 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:50:55 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:50:55 --> 404 Page Not Found: /index
ERROR - 2022-06-16 12:51:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:51:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:51:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:51:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:51:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:55:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:55:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:55:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:55:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:55:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:56:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:56:13 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:56:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:56:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:56:13 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:56:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:56:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:56:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:56:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:56:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:56:59 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\cibase\application\models\Common_model.php 1434
ERROR - 2022-06-16 12:57:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:57:17 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:57:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:57:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:57:17 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:57:17 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\cibase\application\models\Common_model.php 1435
ERROR - 2022-06-16 12:57:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:57:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:57:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:57:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:57:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 12:57:19 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\cibase\application\models\Common_model.php 1435
ERROR - 2022-06-16 12:57:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 12:57:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 12:57:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 12:57:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 12:57:25 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:00:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:00:13 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:00:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:00:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:00:13 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:00:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:00:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:00:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:00:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:00:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:00:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:00:22 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:00:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:00:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:00:22 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:00:22 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-16 13:00:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:00:25 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:00:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:00:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:00:25 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:00:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:00:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:00:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:00:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:00:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:00:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:00:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:00:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:00:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:00:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:00:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:00:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:00:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:00:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:00:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:02:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:02:25 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:02:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:02:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:02:25 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:02:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:02:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:02:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:02:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:02:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:02:33 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\cibase\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-06-16 13:02:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-06-16 13:02:33 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\cibase\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-06-16 13:02:33 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 13:02:33 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 13:02:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:02:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:02:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:02:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:02:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:02:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\cibase\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-06-16 13:02:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-06-16 13:02:52 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\cibase\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-06-16 13:02:52 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 13:02:52 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 13:02:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:02:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:02:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:02:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:02:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:02:56 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:03:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:03:04 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:03:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:03:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:03:04 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:03:04 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:03:04 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:03:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:03:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:03:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:03:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:03:12 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:03:12 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\cibase\application\modules\user\controllers\User.php 426
ERROR - 2022-06-16 13:03:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:03:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:03:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:03:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:03:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:03:19 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:03:19 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:03:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:03:21 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:03:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:03:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:03:21 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:03:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 13:08:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:08:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:08:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:08:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:08:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:08:51 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:09:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:09:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:09:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:09:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:09:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:09:11 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:14:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:14:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:14:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:14:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:14:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:14:37 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\cibase\application\modules\user\controllers\User.php 426
ERROR - 2022-06-16 13:14:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:14:43 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:14:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:14:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:14:43 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:14:43 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:14:43 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:16:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:16:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:16:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:16:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:16:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:16:06 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:16:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:16:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:16:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:16:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:16:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:16:09 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:16:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:16:17 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:16:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:16:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:16:17 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:16:17 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:16:17 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:16:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:16:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:16:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:16:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:16:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:16:48 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:16:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:16:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:16:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:16:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:16:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:16:51 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:16:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:16:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:16:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:16:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:16:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:16:56 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:16:56 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:17:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:17:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:17:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:17:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:17:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:17:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 13:17:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:17:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:17:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:17:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:17:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:18:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:18:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:18:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:18:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:18:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:18:48 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:18:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:18:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:18:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:18:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:18:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:18:50 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 13:19:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:19:57 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:19:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:19:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:19:57 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:19:57 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:19:57 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:20:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:20:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:20:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:20:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:20:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:20:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> Undefined array key "permission" C:\xampp\htdocs\cibase\application\models\Usergroup_model.php 28
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:20:08 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:20:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:20:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:20:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:20:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:20:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:20:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:20:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:20:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:20:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:20:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:20:16 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:20:16 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:20:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:20:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:20:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:20:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:20:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:20:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 13:24:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:24:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:24:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:24:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:24:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:24:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 13:24:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:24:22 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:24:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:24:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:24:22 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:24:22 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:24:22 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:24:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:24:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:24:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:24:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:24:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:24:28 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:24:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:24:46 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:24:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:24:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:24:46 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:24:46 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:24:46 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:24:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:24:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:24:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:24:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:24:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:01 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:25:01 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:25:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:04 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:04 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:04 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:25:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:07 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:07 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:08 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 13:25:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:16 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:25:16 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:25:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:31 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:25:31 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:25:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:34 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:34 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:34 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:34 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:35 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:25:35 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:25:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:39 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:39 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:39 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:39 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:39 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:25:39 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:25:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:44 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:44 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:25:44 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:25:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:25:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:25:44 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:25:44 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:25:44 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:26:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:26:12 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:26:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:26:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:26:12 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:26:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:26:12 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:26:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:26:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:26:12 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:26:12 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:26:12 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:26:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:26:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:26:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:26:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:26:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:26:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:26:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:26:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:26:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:26:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:26:15 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:26:15 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:26:18 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:26:18 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:26:18 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:26:18 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:26:18 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:26:18 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:26:18 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:29:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:29:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:29:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:29:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:29:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:29:36 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:29:36 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:30:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:30:21 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:30:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:30:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:30:21 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:30:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 13:30:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:30:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:30:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:30:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:30:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:30:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:30:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:30:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:30:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:30:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:30:35 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:30:35 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:30:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:30:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:30:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:30:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:30:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:30:42 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:30:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:30:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:30:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:30:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:30:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:30:53 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 13:30:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:30:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:30:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:30:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:30:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:30:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:30:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:30:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:30:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:30:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:31:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:31:12 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:31:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:31:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:31:12 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:31:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:31:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:31:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:31:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:31:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:31:19 --> Severity: Warning --> Undefined array key "audit_record" C:\xampp\htdocs\cibase\application\models\User_model.php 13
ERROR - 2022-06-16 13:31:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:31:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:31:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:31:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:31:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:31:19 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:31:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:31:25 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:31:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:31:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:31:25 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:31:25 --> Severity: Warning --> foreach() argument must be of type array|object, bool given C:\xampp\htdocs\cibase\application\views\common\filter.php 138
ERROR - 2022-06-16 13:31:25 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\cibase\application\views\common\filter.php 151
ERROR - 2022-06-16 13:31:25 --> Severity: Warning --> Attempt to read property "COLUMN_NAME" on null C:\xampp\htdocs\cibase\application\views\common\filter.php 151
ERROR - 2022-06-16 13:31:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:31:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:31:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:31:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:31:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:31:42 --> Severity: Warning --> foreach() argument must be of type array|object, bool given C:\xampp\htdocs\cibase\application\views\common\filter.php 138
ERROR - 2022-06-16 13:31:42 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\cibase\application\views\common\filter.php 151
ERROR - 2022-06-16 13:31:42 --> Severity: Warning --> Attempt to read property "COLUMN_NAME" on null C:\xampp\htdocs\cibase\application\views\common\filter.php 151
ERROR - 2022-06-16 13:31:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:31:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:31:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:31:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:31:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:31:48 --> Severity: Warning --> foreach() argument must be of type array|object, bool given C:\xampp\htdocs\cibase\application\views\common\filter.php 138
ERROR - 2022-06-16 13:31:48 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\cibase\application\views\common\filter.php 151
ERROR - 2022-06-16 13:31:48 --> Severity: Warning --> Attempt to read property "COLUMN_NAME" on null C:\xampp\htdocs\cibase\application\views\common\filter.php 151
ERROR - 2022-06-16 13:31:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:31:57 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:31:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:31:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:31:57 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:31:57 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 13:32:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:32:12 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:32:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:32:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:32:12 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:32:12 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:32:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:32:20 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:32:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:32:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:32:20 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:32:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:32:20 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:32:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:32:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:32:20 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:32:20 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:32:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:32:32 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:32:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:32:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:32:32 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:32:32 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 13:32:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:32:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:32:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:32:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:32:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:32:38 --> Severity: Warning --> Undefined array key "audit_record" C:\xampp\htdocs\cibase\application\models\User_model.php 42
ERROR - 2022-06-16 13:32:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:32:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:32:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:32:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:32:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:32:38 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:32:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:32:47 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:32:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:32:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:32:47 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:32:47 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 13:32:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:32:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:32:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:32:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:32:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:32:58 --> Severity: Warning --> Undefined array key "audit_record" C:\xampp\htdocs\cibase\application\models\User_model.php 42
ERROR - 2022-06-16 13:32:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:32:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:32:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:32:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:32:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:32:59 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:33:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:33:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:33:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:33:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:33:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:33:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:33:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:33:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:33:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:33:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:33:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:33:14 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:33:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:33:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:33:14 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:33:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:33:14 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:33:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:33:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:33:14 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:33:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:33:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:33:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:33:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:33:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:33:27 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:33:27 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\cibase\application\views\common\header.php 13
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\cibase\application\views\common\menu.php 98
ERROR - 2022-06-16 13:33:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\cibase\application\views\common\menu.php 106
ERROR - 2022-06-16 13:33:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:33:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:33:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:33:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:33:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:33:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:33:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:33:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:33:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:33:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:33:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:33:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:33:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:33:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:33:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:33:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:33:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:33:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:33:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:33:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:33:42 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:01 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:06 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:07 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:07 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:07 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:08 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:09 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:09 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:09 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:09 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:09 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:10 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:10 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:10 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:16 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:21 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:21 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:21 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:26 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\cibase\application\views\common\header.php 13
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\cibase\application\views\common\menu.php 98
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\cibase\application\views\common\menu.php 106
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:27 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:28 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:29 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:30 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:30 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:30 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:30 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:31 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:31 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:31 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:31 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:32 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:32 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:32 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:36:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:36:32 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:36:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:36:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:36:32 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:36:32 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:37:00 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:37:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:38:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:39:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:39:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:39:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:39:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:39:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:39:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:39:07 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:39:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:39:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:39:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:39:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:39:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:40:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:40:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:40:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:40:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:40:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:40:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:40:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:40:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:40:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:40:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:40:02 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:40:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:40:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:40:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:40:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:40:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:40:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:40:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:40:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:40:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:40:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:40:11 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:40:12 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:40:13 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:40:46 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:40:48 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:42:38 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:42:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:42:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:42:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:42:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:42:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:42:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:42:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:42:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:42:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:42:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:43:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:43:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:43:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:43:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:43:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:43:08 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:43:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:43:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:43:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:43:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:43:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:43:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:43:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:43:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:43:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:43:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:43:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:43:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:43:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:43:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:43:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:43:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:43:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:43:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:43:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:43:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:43:28 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:45:22 --> 404 Page Not Found: /index
ERROR - 2022-06-16 13:45:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:45:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:45:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:45:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:45:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:45:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:45:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:45:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:45:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:45:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:45:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:45:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:45:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:45:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:45:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:45:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:45:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:45:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:45:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:45:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:45:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:45:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:45:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:45:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:45:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:45:51 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:45:51 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:47:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:47:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:47:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:47:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:47:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:47:01 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:47:01 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:47:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:47:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:47:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:47:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:47:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:47:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 13:51:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:51:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:51:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:51:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:51:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:51:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 13:51:19 --> Severity: Warning --> foreach() argument must be of type array|object, bool given C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 70
ERROR - 2022-06-16 13:51:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:51:36 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:51:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:51:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:51:36 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:51:36 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:51:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:51:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:51:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:51:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:51:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:51:50 --> Severity: Warning --> foreach() argument must be of type array|object, bool given C:\xampp\htdocs\cibase\application\views\common\filter.php 138
ERROR - 2022-06-16 13:51:50 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\cibase\application\views\common\filter.php 151
ERROR - 2022-06-16 13:51:50 --> Severity: Warning --> Attempt to read property "COLUMN_NAME" on null C:\xampp\htdocs\cibase\application\views\common\filter.php 151
ERROR - 2022-06-16 13:52:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:52:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:52:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:52:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:52:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:52:28 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:52:28 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:52:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:52:34 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:52:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:52:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:52:34 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:52:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 13:52:34 --> Severity: Warning --> foreach() argument must be of type array|object, bool given C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 70
ERROR - 2022-06-16 13:55:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:55:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:55:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:55:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:55:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:55:15 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:55:15 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:55:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:55:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:55:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:55:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:55:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:55:26 --> Severity: Warning --> foreach() argument must be of type array|object, bool given C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 181
ERROR - 2022-06-16 13:58:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:58:49 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:58:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:58:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:58:49 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:58:49 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 13:58:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:58:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:58:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:58:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:58:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:58:54 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 13:58:54 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 13:59:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 13:59:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 13:59:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 13:59:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 13:59:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 13:59:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 13:59:37 --> Severity: Warning --> foreach() argument must be of type array|object, bool given C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 70
ERROR - 2022-06-16 14:01:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:01:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:01:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:01:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:01:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:01:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:01:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:01:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:01:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:01:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:01:29 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 14:01:29 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 14:02:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:02:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:02:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:02:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:02:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:02:02 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 14:02:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:02:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:02:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:02:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:02:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:02:09 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 14:02:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:02:12 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:02:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:02:12 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:02:12 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:03:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:03:43 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:03:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:03:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:03:43 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:03:43 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 14:03:43 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 14:03:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:03:46 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:03:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:03:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:03:46 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:03:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 14:03:46 --> Severity: Warning --> foreach() argument must be of type array|object, bool given C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 70
ERROR - 2022-06-16 14:06:04 --> 404 Page Not Found: ../modules/master/controllers/Master/modulekey
ERROR - 2022-06-16 14:06:11 --> 404 Page Not Found: ../modules/master/controllers/Master/modulekey
ERROR - 2022-06-16 14:06:16 --> 404 Page Not Found: ../modules/master/controllers/Master/module_key
ERROR - 2022-06-16 14:06:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:06:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:06:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:06:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:06:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:06:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\master\controllers\Master.php 9
ERROR - 2022-06-16 14:06:24 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\cibase\application\modules\master\controllers\Master.php 41
ERROR - 2022-06-16 14:06:24 --> Severity: Warning --> Attempt to read property "menu_table_name" on null C:\xampp\htdocs\cibase\application\modules\master\controllers\Master.php 41
ERROR - 2022-06-16 14:06:24 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\cibase\application\modules\master\controllers\Master.php 42
ERROR - 2022-06-16 14:06:24 --> Severity: Warning --> Attempt to read property "menu_alias_name" on null C:\xampp\htdocs\cibase\application\modules\master\controllers\Master.php 42
ERROR - 2022-06-16 14:06:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '* FROM   WHERE  .transaction_id = 0 AND  .delete_status = 0' at line 1 - Invalid query: SELECT .* FROM   WHERE  .transaction_id = 0 AND  .delete_status = 0
ERROR - 2022-06-16 14:06:24 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\xampp\htdocs\cibase\application\models\Common_model.php 1194
ERROR - 2022-06-16 14:06:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:06:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:06:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:06:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:06:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:06:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\master\controllers\Master.php 9
ERROR - 2022-06-16 14:06:30 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\master\views\master_list_view.php 53
ERROR - 2022-06-16 14:06:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:06:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:06:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:06:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:06:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:06:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\master\controllers\Master.php 9
ERROR - 2022-06-16 14:07:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:07:07 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:07:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:07:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:07:07 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:07:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\master\controllers\Master.php 9
ERROR - 2022-06-16 14:07:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:07:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:07:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:07:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:07:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:07:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\master\controllers\Master.php 9
ERROR - 2022-06-16 14:07:11 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\master\views\master_list_view.php 53
ERROR - 2022-06-16 14:07:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:07:20 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:07:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:07:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:07:20 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:07:20 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 14:07:20 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 14:07:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:07:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:07:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:07:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:07:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:09:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:09:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:09:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:09:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:09:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:09:27 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 14:42:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:42:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:42:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:42:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:42:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:42:09 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 14:42:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:42:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:42:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:42:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:42:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:42:16 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 14:43:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:43:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:43:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:43:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:43:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:43:16 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 14:43:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:43:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:43:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:43:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:43:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:43:51 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 14:44:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:44:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:44:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:44:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:44:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:44:19 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 14:44:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:44:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:44:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:44:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:44:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:44:26 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 14:45:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:45:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:45:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:45:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:45:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:45:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:45:25 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:45:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:45:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:45:25 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:45:25 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 14:45:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:45:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:45:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:45:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:45:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:47:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:47:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:47:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:47:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:47:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:47:03 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 14:47:03 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 14:47:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:47:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:47:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:47:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:47:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:47:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 14:50:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:50:14 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:50:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:50:14 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:50:14 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:50:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 14:56:42 --> 404 Page Not Found: /index
ERROR - 2022-06-16 14:56:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:56:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:56:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:56:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:56:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:56:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:56:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:56:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:56:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:56:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:57:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:57:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:57:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:57:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:57:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:57:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:57:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:57:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:57:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:57:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:59:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:59:32 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:59:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:59:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:59:32 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 14:59:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 14:59:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 14:59:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 14:59:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 14:59:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:00:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:00:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:00:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:00:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:00:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:00:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:00:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:00:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:00:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:00:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:00:15 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 15:00:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:00:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:00:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:00:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:00:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:00:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:00:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:00:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:00:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:00:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:00:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:00:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:00:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:00:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:00:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:00:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:00:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:00:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:00:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:00:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:00:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:00:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:00:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:00:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:00:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:01:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:01:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:01:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:01:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:01:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:01:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:01:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:01:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:01:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:01:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:01:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:01:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:01:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:01:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:01:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:02:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:02:23 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:02:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:02:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:02:23 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:02:23 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 15:02:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:02:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:02:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:02:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:02:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:02:29 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1859
ERROR - 2022-06-16 15:02:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:02:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:02:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:02:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:02:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:02:37 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 15:02:37 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 15:02:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:02:44 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:02:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:02:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:02:44 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:02:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 15:03:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:03:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:03:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:03:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:03:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:03:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 15:04:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:04:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:04:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:04:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:04:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:04:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 48
ERROR - 2022-06-16 15:05:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:05:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:05:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:05:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:05:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:05:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-06-16 15:06:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:06:57 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:06:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:06:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:06:57 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-06-16 15:08:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 15:08:47 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 15:08:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 15:08:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 15:08:47 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 15:08:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-06-16 16:59:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 16:59:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 16:59:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 16:59:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 16:59:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 16:59:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 16:59:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 16:59:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 16:59:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 16:59:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 16:59:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 16:59:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 16:59:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 16:59:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 16:59:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 16:59:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 16:59:49 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 16:59:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 16:59:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 16:59:49 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 16:59:49 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 16:59:49 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 17:00:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 17:00:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 17:00:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 17:00:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 17:00:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 17:00:03 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 17:00:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 17:00:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 17:00:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 17:00:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 17:00:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 17:00:19 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 17:00:19 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 17:04:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 17:04:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 17:04:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 17:04:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 17:04:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 17:04:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 17:04:45 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 17:04:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 17:04:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 17:04:45 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 17:04:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 17:04:49 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 17:04:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 17:04:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 17:04:49 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 17:04:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 17:04:49 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 17:04:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 17:04:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 17:04:49 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 17:05:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 17:05:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 17:05:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 17:05:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 17:05:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 17:05:50 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 17:05:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 17:05:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 17:05:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 17:05:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 17:05:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 17:05:53 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 17:05:53 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 17:05:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 17:05:57 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 17:05:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 17:05:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 17:05:57 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 17:06:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 17:06:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 17:06:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 17:06:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 17:06:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 17:06:01 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 17:06:01 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 17:06:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 17:06:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 17:06:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 17:06:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 17:06:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:15:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:15:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:15:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:15:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:15:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:15:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:15:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:15:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:15:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:15:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:15:11 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:15:11 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:15:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:15:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:15:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:15:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:15:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:15:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-06-16 18:15:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:15:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:15:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:15:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:15:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:15:19 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:15:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:15:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:15:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:15:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:15:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:15:28 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-06-16 18:15:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:15:32 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:15:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:15:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:15:32 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:15:32 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:15:32 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:15:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:15:34 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:15:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:15:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:15:34 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:15:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:15:45 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:15:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:15:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:15:45 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:15:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:15:46 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:15:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:15:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:15:46 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:15:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:15:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:15:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:15:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:15:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:15:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:15:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:15:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:15:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:15:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:16:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:16:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:16:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:16:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:16:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:16:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:16:23 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:16:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:16:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:16:23 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:16:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:16:23 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:16:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:16:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:16:23 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:16:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:16:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:16:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:16:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:16:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:16:31 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:16:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:16:36 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:16:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:16:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:16:36 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:16:36 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:16:36 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\header.php 13
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\menu.php 98
ERROR - 2022-06-16 18:16:40 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\menu.php 106
ERROR - 2022-06-16 18:16:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:16:45 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:16:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:16:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:16:45 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:16:45 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:16:45 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\header.php 13
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\menu.php 98
ERROR - 2022-06-16 18:16:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\menu.php 106
ERROR - 2022-06-16 18:16:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:16:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:16:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:16:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:16:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:16:50 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:16:50 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:17:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:17:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:17:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:17:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:17:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:17:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-06-16 18:17:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:17:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:17:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:17:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:17:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:17:16 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:17:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:17:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:17:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:17:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:17:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:17:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\user\controllers\User.php 14
ERROR - 2022-06-16 18:17:24 --> 404 Page Not Found: /index
ERROR - 2022-06-16 18:17:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:17:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:17:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:17:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:17:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:17:36 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\printcare\application\models\Login_model.php 76
ERROR - 2022-06-16 18:17:36 --> Severity: Warning --> Attempt to read property "log_id" on null C:\xampp\htdocs\printcare\application\models\Login_model.php 76
ERROR - 2022-06-16 18:17:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:17:36 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:17:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:17:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:17:36 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:17:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:17:43 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:17:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:17:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:17:43 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:17:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:17:43 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:17:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:17:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:17:43 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:21:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:21:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:21:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:21:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:21:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:21:15 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:21:15 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:21:18 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:21:18 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:21:18 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:21:18 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:21:18 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:21:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:21:36 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:21:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:21:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:21:36 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:21:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:21:36 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:21:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:21:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:21:36 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:21:36 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:21:36 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:21:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:21:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:21:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:21:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:21:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:21:42 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:21:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:21:49 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:21:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:21:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:21:49 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:21:49 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:21:49 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:21:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:21:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:21:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:21:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:21:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:21:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-06-16 18:22:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:22:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:22:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:22:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:22:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:22:06 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:22:06 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:22:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:22:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:22:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:22:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:22:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:22:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:22:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:22:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:22:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:22:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:22:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:22:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:22:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:22:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:22:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:22:29 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:22:29 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:22:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:22:36 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:22:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:22:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:22:36 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:22:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-06-16 18:22:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:22:39 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:22:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:22:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:22:39 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:22:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:22:39 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:22:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:22:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:22:39 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:22:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:22:46 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:22:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:22:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:22:46 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:22:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:22:46 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:22:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:22:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:22:46 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:22:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:22:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:22:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:22:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:22:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:22:52 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:22:52 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\header.php 13
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\menu.php 98
ERROR - 2022-06-16 18:22:59 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\menu.php 106
ERROR - 2022-06-16 18:23:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:23:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:23:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:23:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:23:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:23:01 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:23:01 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\header.php 13
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\menu.php 98
ERROR - 2022-06-16 18:23:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\menu.php 106
ERROR - 2022-06-16 18:23:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:23:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:23:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:23:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:23:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:23:52 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:23:52 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\header.php 13
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\menu.php 98
ERROR - 2022-06-16 18:23:56 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\menu.php 106
ERROR - 2022-06-16 18:23:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:23:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:23:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:23:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:23:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:23:59 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:23:59 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:24:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:24:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:24:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:24:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:24:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:24:02 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:24:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:24:36 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:24:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:24:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:24:36 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:24:36 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:24:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:24:47 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:24:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:24:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:24:47 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:24:47 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:24:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:24:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:24:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:24:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:24:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:24:56 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:25:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:25:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:25:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:25:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:25:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:25:06 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:25:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:25:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:25:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:25:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:25:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:25:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:25:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:25:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:25:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:25:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:25:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\header.php 13
ERROR - 2022-06-16 18:25:11 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\menu.php 98
ERROR - 2022-06-16 18:25:11 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\printcare\application\views\common\menu.php 106
ERROR - 2022-06-16 18:25:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:25:13 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:25:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:25:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:25:13 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:25:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:25:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:25:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:25:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:25:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:25:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:25:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:25:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:25:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:25:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:26:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:26:21 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:26:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:26:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:26:21 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:26:21 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:28:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:28:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:28:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:28:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:28:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:28:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:28:44 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:28:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:28:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:28:44 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:28:46 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:29:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:29:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:29:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:29:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:29:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:29:01 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:29:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:29:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:29:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:29:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:29:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:29:06 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:29:06 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:31:11 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:32:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:32:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:32:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:32:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:32:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:32:30 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:32:30 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:32:31 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:32:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:32:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:32:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:32:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:32:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:32:56 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:32:56 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:32:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:32:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:32:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:32:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:32:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:32:59 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:32:59 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:33:00 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:33:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:33:22 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:33:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:33:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:33:22 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:33:22 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:33:22 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:33:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:33:22 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:33:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:33:22 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:33:22 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:33:23 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:33:23 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:33:33 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:35:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:35:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:35:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:35:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:35:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:35:35 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:35:35 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:35:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:35:36 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:35:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:35:36 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:35:36 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:35:36 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:35:36 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:36:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:36:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:36:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:36:27 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:36:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:36:44 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:36:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:36:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:36:44 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:36:44 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-06-16 18:43:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:43:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:43:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:43:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:43:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:43:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-06-16 18:43:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:43:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:43:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:43:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:43:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:43:41 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:43:41 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:43:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:43:44 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:43:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:43:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:43:44 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:44:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:44:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:44:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:44:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:44:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:44:00 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:44:00 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:44:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:44:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:44:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:44:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:44:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:44:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 49
ERROR - 2022-06-16 18:44:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:44:07 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:44:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:44:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:44:07 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:44:07 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-16 18:44:07 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-16 18:44:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:44:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:44:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:44:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:44:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:46:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:46:40 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:46:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:46:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:46:40 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-06-16 18:46:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-06-16 18:46:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-06-16 18:46:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-06-16 18:46:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-16 18:46:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
