<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-13 15:22:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 15:22:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 15:22:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 15:22:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 15:22:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 15:22:57 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:22:57 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:22:57 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:25:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 15:25:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 15:25:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 15:25:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 15:25:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 15:25:01 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:25:01 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:25:01 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:25:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 15:25:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 15:25:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 15:25:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 15:25:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 15:25:03 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:25:03 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:25:03 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:25:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 15:25:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 15:25:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 15:25:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 15:25:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 15:25:48 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:25:48 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:25:48 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:26:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 15:26:20 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 15:26:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 15:26:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 15:26:20 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 15:26:20 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:26:20 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:26:20 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:28:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 15:28:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 15:28:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 15:28:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 15:28:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 15:28:03 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:28:03 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:28:03 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:28:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 15:28:44 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 15:28:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 15:28:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 15:28:44 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 15:28:44 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:28:44 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:28:44 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:29:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 15:29:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 15:29:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 15:29:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 15:29:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 15:29:01 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:29:01 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:29:01 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:29:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 15:29:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 15:29:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 15:29:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 15:29:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 15:29:05 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:29:05 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:29:05 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:31:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 15:31:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 15:31:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 15:31:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 15:31:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 15:31:35 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:31:35 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-06-13 15:31:35 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:32:36 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:32:36 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-06-13 15:32:36 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:40:41 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:40:41 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-06-13 15:40:41 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:41:03 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:41:03 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-06-13 15:41:03 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:41:04 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:41:04 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-06-13 15:41:04 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:42:01 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:42:01 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-06-13 15:42:01 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:42:45 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:42:58 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:42:58 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-06-13 15:42:58 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:43:46 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 15:43:46 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-06-13 15:43:46 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:44:09 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:44:56 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:44:58 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:44:59 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:44:59 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:44:59 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:45:00 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:50:37 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:51:46 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 15:53:15 --> Severity: Warning --> Undefined property: stdClass::$ref_employee_id C:\xampp\htdocs\cibase\application\modules\login\controllers\Login.php 128
ERROR - 2022-06-13 15:53:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\dashboard\controllers\Dashboard.php 14
ERROR - 2022-06-13 15:53:15 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 15:53:15 --> 404 Page Not Found: /index
ERROR - 2022-06-13 15:53:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\dashboard\controllers\Dashboard.php 14
ERROR - 2022-06-13 15:53:39 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 15:53:39 --> 404 Page Not Found: /index
ERROR - 2022-06-13 15:53:58 --> 404 Page Not Found: /index
ERROR - 2022-06-13 15:54:20 --> 404 Page Not Found: /index
ERROR - 2022-06-13 15:54:35 --> Severity: Warning --> Undefined property: stdClass::$ref_employee_id C:\xampp\htdocs\cibase\application\modules\login\controllers\Login.php 128
ERROR - 2022-06-13 15:54:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\dashboard\controllers\Dashboard.php 14
ERROR - 2022-06-13 15:54:35 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 15:54:35 --> 404 Page Not Found: /index
ERROR - 2022-06-13 15:55:43 --> 404 Page Not Found: /index
ERROR - 2022-06-13 15:55:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\dashboard\controllers\Dashboard.php 14
ERROR - 2022-06-13 15:55:49 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 15:55:49 --> 404 Page Not Found: /index
ERROR - 2022-06-13 16:00:52 --> 404 Page Not Found: /index
ERROR - 2022-06-13 16:00:54 --> 404 Page Not Found: /index
ERROR - 2022-06-13 16:02:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\dashboard\controllers\Dashboard.php 14
ERROR - 2022-06-13 16:02:58 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:02:58 --> 404 Page Not Found: /index
ERROR - 2022-06-13 16:04:22 --> 404 Page Not Found: /index
ERROR - 2022-06-13 16:04:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\dashboard\controllers\Dashboard.php 14
ERROR - 2022-06-13 16:04:27 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:04:27 --> 404 Page Not Found: /index
ERROR - 2022-06-13 16:10:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:10:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:10:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:10:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:10:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:10:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:10:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:10:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:10:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:10:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:11:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:11:21 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:11:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:11:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:11:21 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:11:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:11:21 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:11:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:11:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:11:21 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:11:21 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:12:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:12:04 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:12:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:12:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:12:04 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:12:04 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:12:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:12:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:12:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:12:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:12:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:12:19 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:12:20 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-13 16:12:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:12:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:12:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:12:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:12:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:12:33 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:12:33 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-06-13 16:12:33 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-06-13 16:12:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:12:44 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:12:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:12:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:12:44 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:12:44 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:18:52 --> 404 Page Not Found: ../modules/dashboard/controllers/Dashboard/branch_selection
ERROR - 2022-06-13 16:18:54 --> 404 Page Not Found: ../modules/dashboard/controllers/Dashboard/branch_selection
ERROR - 2022-06-13 16:21:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:21:40 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:21:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:21:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:21:40 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:21:40 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:21:40 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\cibase\application\modules\user\controllers\User.php 426
ERROR - 2022-06-13 16:21:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:21:57 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:21:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:21:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:21:57 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:21:57 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:21:57 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\cibase\application\modules\user\controllers\User.php 426
ERROR - 2022-06-13 16:22:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:22:13 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:22:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:22:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:22:13 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:22:13 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:22:13 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\cibase\application\modules\user\controllers\User.php 426
ERROR - 2022-06-13 16:23:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:23:06 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:23:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:23:06 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:23:06 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:23:06 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:23:06 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-13 16:23:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:23:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:23:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:23:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:23:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:23:52 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:23:52 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:24:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:24:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:24:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:24:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:24:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:24:59 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 16:25:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:25:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:25:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:25:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:25:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:25:08 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 16:25:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:25:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:25:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:25:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:25:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:25:11 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:25:11 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:25:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:25:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:25:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:25:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:25:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:25:16 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 16:25:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:25:23 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:25:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:25:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:25:23 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:25:23 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 16:25:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:25:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:25:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:25:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:25:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:25:38 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 16:25:38 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-06-13 16:25:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cibase\system\core\Exceptions.php:272) C:\xampp\htdocs\cibase\system\core\Common.php 573
ERROR - 2022-06-13 16:25:38 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 16:26:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:26:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:26:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:26:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:26:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:26:37 --> Severity: 8192 --> Required parameter $user follows optional parameter $sort_data C:\xampp\htdocs\cibase\application\models\User_model.php 91
ERROR - 2022-06-13 16:26:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:26:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:26:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:26:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:26:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:26:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:26:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:26:48 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:26:48 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:26:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:26:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:26:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:26:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:26:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:26:50 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:26:50 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\cibase\application\modules\user\views\user_list.php 134
ERROR - 2022-06-13 16:27:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:27:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:27:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:27:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:27:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:27:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:27:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:27:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:27:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:27:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:27:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:27:13 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:27:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:27:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:27:13 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:27:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:27:23 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:27:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:27:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:27:23 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:27:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:27:23 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:27:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:27:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:27:23 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:27:23 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:27:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:27:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:27:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:27:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:27:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:27:42 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 16:27:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:27:44 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:27:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:27:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:27:44 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:27:45 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:27:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:27:49 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:27:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:27:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:27:49 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:27:49 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 16:27:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:27:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:27:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:27:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:27:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:27:52 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:28:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:28:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:28:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:28:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:28:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:28:00 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:28:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:28:07 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:28:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:28:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:28:07 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:28:07 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 16:28:07 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-06-13 16:28:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cibase\system\core\Exceptions.php:272) C:\xampp\htdocs\cibase\system\core\Common.php 573
ERROR - 2022-06-13 16:28:07 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 16:30:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:30:25 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:30:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:30:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:30:25 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:30:25 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:30:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:30:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:30:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:30:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:30:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:30:31 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 16:30:31 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-06-13 16:30:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cibase\system\core\Exceptions.php:272) C:\xampp\htdocs\cibase\system\core\Common.php 573
ERROR - 2022-06-13 16:30:31 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 16:31:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:31:34 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:31:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:31:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:31:34 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:31:34 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:31:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:31:46 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:31:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:31:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:31:46 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:31:47 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:31:47 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:31:47 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:32:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:32:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:32:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:32:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:32:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:32:05 --> Severity: Warning --> session_regenerate_id(): Session ID cannot be regenerated after headers have already been sent C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 625
ERROR - 2022-06-13 16:32:05 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-06-13 16:32:05 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-06-13 16:32:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\cibase\system\core\Exceptions.php:272) C:\xampp\htdocs\cibase\system\core\Common.php 573
ERROR - 2022-06-13 16:32:05 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 16:33:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:33:13 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:33:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:33:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:33:13 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:33:13 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:33:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:33:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:33:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:33:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:33:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:33:29 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:33:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:33:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:33:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:33:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:33:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:33:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:33:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:33:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:33:37 --> Severity: Warning --> Undefined variable $supplier_html C:\xampp\htdocs\cibase\application\modules\purchase_order\views\script_purchase_order.php 83
ERROR - 2022-06-13 16:33:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:33:57 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:33:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:33:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:33:57 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:34:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:34:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:34:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:34:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:34:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:34:16 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:34:16 --> Severity: Warning --> Undefined array key "special_instruction" C:\xampp\htdocs\cibase\application\modules\purchase_order\controllers\Purchase_order.php 701
ERROR - 2022-06-13 16:34:16 --> Severity: error --> Exception: Class "mPDF" not found C:\xampp\htdocs\cibase\application\models\Common_model.php 1479
ERROR - 2022-06-13 16:34:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:34:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:34:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:34:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:34:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:34:19 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:34:19 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:34:19 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:34:19 --> Severity: Warning --> Undefined variable $supplier_html C:\xampp\htdocs\cibase\application\modules\purchase_order\views\script_purchase_order.php 83
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Attempt to read property "sub_total" on null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Attempt to read property "sub_total" on null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Attempt to read property "supp_discount_total" on null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Attempt to read property "supp_discount_total" on null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Attempt to read property "gst_total" on null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Attempt to read property "gst_total" on null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Attempt to read property "grand_total" on null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Attempt to read property "grand_total" on null C:\xampp\htdocs\cibase\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-06-13 16:34:26 --> Severity: Warning --> Undefined variable $supplier_html C:\xampp\htdocs\cibase\application\modules\purchase_order\views\script_purchase_order.php 83
ERROR - 2022-06-13 16:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:38:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:38:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:38:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:38:05 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-06-13 16:38:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:38:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:38:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:38:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:38:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:38:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\cibase\application\modules\product\controllers\Product.php 226
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\cibase\system\libraries\Parser.php 144
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 19
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 19
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Attempt to read property "ref_category_id" on null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 19
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 29
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 29
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Attempt to read property "product_name" on null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 29
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 37
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 37
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Attempt to read property "sku" on null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 37
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 46
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 46
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Attempt to read property "unit" on null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 46
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 57
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 57
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Attempt to read property "ref_stock_room_id" on null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 57
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 70
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 70
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Attempt to read property "ref_stock_slot_id" on null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 70
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 92
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 92
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Attempt to read property "ref_quantity_type_id" on null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 92
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 115
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 115
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Attempt to read property "ref_gst_type_id" on null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 115
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 145
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 145
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Attempt to read property "featured_product" on null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 145
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 153
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 153
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Attempt to read property "display_homepage" on null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 153
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 164
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 164
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Attempt to read property "ref_star_rating_id" on null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 164
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 187
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 187
ERROR - 2022-06-13 16:39:34 --> Severity: Warning --> Attempt to read property "product_image_file" on null C:\xampp\htdocs\cibase\application\modules\product\views\product_form_view.php 187
ERROR - 2022-06-13 16:39:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:39:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:39:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:39:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:39:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:39:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:39:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:39:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:39:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:39:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:39:35 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\cibase\application\models\Common_model.php 1858
ERROR - 2022-06-13 16:42:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 281
ERROR - 2022-06-13 16:42:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 293
ERROR - 2022-06-13 16:42:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 303
ERROR - 2022-06-13 16:42:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-06-13 16:42:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\cibase\system\libraries\Session\Session.php 107
ERROR - 2022-06-13 16:42:00 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\cibase\application\libraries\mpdf\mpdf.php 1984
