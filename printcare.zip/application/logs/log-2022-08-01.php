<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-01 09:54:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 09:54:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 09:54:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 09:54:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 09:54:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 09:54:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 09:54:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 09:54:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 09:54:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 09:54:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 09:54:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 09:54:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 09:54:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 09:54:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 09:54:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 09:58:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 09:58:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 09:58:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 09:58:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 09:58:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 09:58:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 09:58:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 09:58:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 09:58:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 09:58:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:07:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:07:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:07:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:07:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:07:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:07:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\master\controllers\Master.php 9
ERROR - 2022-08-01 10:07:52 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\master\views\master_list_view.php 53
ERROR - 2022-08-01 10:07:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:07:57 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:07:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:07:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:07:57 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:07:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\master\controllers\Master.php 9
ERROR - 2022-08-01 10:08:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:08:04 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:08:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:08:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:08:04 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:08:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\master\controllers\Master.php 9
ERROR - 2022-08-01 10:08:04 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\master\views\master_list_view.php 53
ERROR - 2022-08-01 10:08:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:08:13 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:08:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:08:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:08:13 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:08:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\master\controllers\Master.php 9
ERROR - 2022-08-01 10:14:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:14:23 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:14:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:14:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:14:23 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:14:23 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-08-01 10:14:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:14:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:14:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:14:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:14:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:14:26 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-08-01 10:14:26 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-08-01 10:14:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:14:43 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:14:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:14:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:14:43 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:14:43 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-08-01 10:14:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:14:46 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:14:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:14:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:14:46 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:14:46 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-08-01 10:14:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:14:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:14:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:14:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:14:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:14:52 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-08-01 10:14:52 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-08-01 10:15:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:15:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:15:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:15:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:15:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:31:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:31:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:31:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:31:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:31:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:31:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:31:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:31:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:31:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:31:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:31:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:31:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:31:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:31:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:31:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:31:24 --> Severity: Warning --> Undefined array key 0 C:\xampp\htdocs\printcare\application\models\Login_model.php 76
ERROR - 2022-08-01 10:31:24 --> Severity: Warning --> Attempt to read property "log_id" on null C:\xampp\htdocs\printcare\application\models\Login_model.php 76
ERROR - 2022-08-01 10:31:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:31:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:31:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:31:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:31:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:31:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:31:42 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:31:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:31:42 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:31:42 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:31:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:31:43 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:31:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:31:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:31:43 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:35:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:35:21 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:35:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:35:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:35:21 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:35:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:35:21 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:35:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:35:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:35:21 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:37:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:37:49 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:37:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:37:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:37:49 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:37:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:37:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:37:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:38:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:38:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:38:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:38:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:38:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:39:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:39:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:39:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:39:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:39:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:41:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:41:20 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:41:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:41:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:41:20 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:41:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:41:32 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:41:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:41:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:41:32 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:41:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:41:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:41:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:41:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:41:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:41:37 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-01 10:41:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-01 10:41:37 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-01 10:41:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-08-01 10:41:37 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-08-01 10:42:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:42:07 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:42:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:42:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:42:07 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Attempt to read property "sub_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Attempt to read property "sub_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 120
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Attempt to read property "supp_discount_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Attempt to read property "supp_discount_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 125
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Attempt to read property "gst_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Attempt to read property "gst_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 130
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Attempt to read property "grand_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Undefined variable $purchase_order C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Attempt to read property "grand_total" on null C:\xampp\htdocs\printcare\application\modules\purchase_order\views\purchase_order_form_view.php 136
ERROR - 2022-08-01 10:42:13 --> Severity: Warning --> Undefined variable $supplier_html C:\xampp\htdocs\printcare\application\modules\purchase_order\views\script_purchase_order.php 83
ERROR - 2022-08-01 10:42:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:42:20 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:42:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:42:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:42:20 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:42:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:42:25 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:42:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:42:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:42:25 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:42:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:42:39 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:42:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:42:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:42:39 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:42:40 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\printcare\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-08-01 10:42:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:42:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:42:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:42:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:42:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:42:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:42:52 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:42:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:42:52 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:42:52 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:42:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:42:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:42:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:42:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:42:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\printcare\application\modules\product\controllers\Product.php 226
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\printcare\system\libraries\Parser.php 144
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 19
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 19
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Attempt to read property "ref_category_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 19
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 29
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 29
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Attempt to read property "product_name" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 29
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 37
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 37
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Attempt to read property "sku" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 37
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 46
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 46
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Attempt to read property "unit" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 46
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 57
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 57
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Attempt to read property "ref_stock_room_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 57
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 70
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 70
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Attempt to read property "ref_stock_slot_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 70
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 92
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 92
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Attempt to read property "ref_quantity_type_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 92
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 115
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 115
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Attempt to read property "ref_gst_type_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 115
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 145
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 145
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Attempt to read property "featured_product" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 145
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 153
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 153
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Attempt to read property "display_homepage" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 153
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 164
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 164
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Attempt to read property "ref_star_rating_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 164
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1859
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 187
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 187
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> Attempt to read property "product_image_file" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 187
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:43:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:43:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:43:21 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:43:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:43:21 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:43:21 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:43:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:43:29 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:43:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:43:29 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:43:29 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:43:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:43:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:43:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:43:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:43:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:43:31 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\printcare\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-08-01 10:43:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:43:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:43:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:43:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:43:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:45:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:45:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:45:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:45:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:45:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:45:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:45:17 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:45:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:45:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:45:17 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:45:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:45:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:45:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:45:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:45:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:45:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:45:43 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:45:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:45:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:45:43 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:45:43 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-08-01 10:45:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:45:47 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:45:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:45:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:45:47 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:45:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:45:50 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:45:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:45:50 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:45:50 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:45:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:45:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:45:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:45:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:45:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:45:53 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\printcare\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-08-01 10:45:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:45:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:45:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:45:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:45:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:48:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:48:45 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:48:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:48:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:48:45 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:48:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:48:57 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:48:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:48:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:48:57 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:48:57 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 10:48:57 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 10:49:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:49:07 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:49:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:49:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:49:07 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:49:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:49:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:49:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:49:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:49:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:49:28 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\printcare\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-08-01 10:49:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:49:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:49:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:49:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:49:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:49:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:49:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:49:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:49:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:49:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\printcare\application\modules\product\controllers\Product.php 226
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\printcare\system\libraries\Parser.php 144
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 19
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 19
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Attempt to read property "ref_category_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 19
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 29
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 29
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Attempt to read property "product_name" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 29
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 37
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 37
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Attempt to read property "sku" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 37
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 46
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 46
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Attempt to read property "unit" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 46
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 57
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 57
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Attempt to read property "ref_stock_room_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 57
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 70
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 70
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Attempt to read property "ref_stock_slot_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 70
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 92
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 92
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Attempt to read property "ref_quantity_type_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 92
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 115
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 115
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Attempt to read property "ref_gst_type_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 115
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 145
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 145
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Attempt to read property "featured_product" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 145
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 153
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 153
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Attempt to read property "display_homepage" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 153
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 164
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 164
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Attempt to read property "ref_star_rating_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 164
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 187
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 187
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> Attempt to read property "product_image_file" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 187
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:49:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:49:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:49:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:49:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:49:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:49:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:50:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:50:04 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:50:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:50:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:50:04 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:50:04 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-01 10:50:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-01 10:50:04 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-01 10:50:04 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 10:50:04 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 10:50:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:50:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:50:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:50:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:50:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:50:15 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-08-01 10:50:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:50:37 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:50:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:50:37 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:50:37 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:50:37 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-08-01 10:50:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:50:40 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:50:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:50:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:50:40 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:50:40 --> Severity: Warning --> Undefined variable $filter_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 33
ERROR - 2022-08-01 10:50:40 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\usergroup\views\usergroup_list.php 67
ERROR - 2022-08-01 10:50:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:50:45 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:50:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:50:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:50:45 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:50:45 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\printcare\application\modules\user\controllers\User.php 426
ERROR - 2022-08-01 10:50:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 10:50:49 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 10:50:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 10:50:49 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 10:50:49 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 10:50:49 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-08-01 11:54:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:54:47 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:54:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:54:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:54:47 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 11:54:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\controllers\Customer.php 17
ERROR - 2022-08-01 11:54:47 --> 404 Page Not Found: /index
ERROR - 2022-08-01 11:54:51 --> 404 Page Not Found: /index
ERROR - 2022-08-01 11:54:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:54:53 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:54:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:54:53 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:54:53 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 11:54:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\user\controllers\User.php 14
ERROR - 2022-08-01 11:54:53 --> 404 Page Not Found: /index
ERROR - 2022-08-01 11:54:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:54:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:54:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:54:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:54:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 11:54:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\user\controllers\User.php 14
ERROR - 2022-08-01 11:54:56 --> 404 Page Not Found: /index
ERROR - 2022-08-01 11:54:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:54:57 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:54:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:54:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:54:57 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 11:54:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\usergroup\controllers\Usergroup.php 12
ERROR - 2022-08-01 11:54:57 --> 404 Page Not Found: /index
ERROR - 2022-08-01 11:54:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:54:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:54:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:54:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:54:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 11:54:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\user\controllers\User.php 14
ERROR - 2022-08-01 11:54:58 --> 404 Page Not Found: /index
ERROR - 2022-08-01 11:55:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:55:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:55:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:55:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:55:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 11:55:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:55:07 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:55:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:55:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:55:07 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 11:55:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:55:07 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:55:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:55:07 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:55:07 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 11:55:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:55:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:55:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:55:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:55:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 11:55:10 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-01 11:55:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-01 11:55:10 --> Severity: Warning --> Attempt to read property "customer_name" on null C:\xampp\htdocs\printcare\application\modules\customer\views\customer_form_view.php 16
ERROR - 2022-08-01 11:55:10 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 11:55:10 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 11:55:13 --> 404 Page Not Found: /index
ERROR - 2022-08-01 11:55:13 --> 404 Page Not Found: /index
ERROR - 2022-08-01 11:55:14 --> 404 Page Not Found: /index
ERROR - 2022-08-01 11:55:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:55:17 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:55:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:55:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:55:17 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 11:55:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:55:17 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:55:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:55:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:55:17 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 11:55:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:55:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:55:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:55:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:55:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 11:56:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 11:56:04 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 11:56:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 11:56:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 11:56:04 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:03:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:03:59 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:03:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:03:59 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:03:59 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:03:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\dashboard\controllers\Dashboard.php 17
ERROR - 2022-08-01 13:03:59 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:04:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:04:08 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:04:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:04:08 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:04:08 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:04:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:04:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:04:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:04:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:04:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:04:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:04:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:04:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:04:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:04:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:04:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:04:20 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:04:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:04:20 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:04:20 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\printcare\application\modules\product\controllers\Product.php 226
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\printcare\system\libraries\Parser.php 144
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 19
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 19
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Attempt to read property "ref_category_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 19
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 29
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 29
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Attempt to read property "product_name" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 29
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 37
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 37
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Attempt to read property "sku" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 37
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 46
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 46
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Attempt to read property "unit" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 46
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 57
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 57
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Attempt to read property "ref_stock_room_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 57
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 70
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 70
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Attempt to read property "ref_stock_slot_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 70
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 92
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 92
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Attempt to read property "ref_quantity_type_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 92
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 115
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 115
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Attempt to read property "ref_gst_type_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 115
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 145
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 145
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Attempt to read property "featured_product" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 145
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 153
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 153
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Attempt to read property "display_homepage" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 153
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 164
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 164
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Attempt to read property "ref_star_rating_id" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 164
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Undefined variable $product C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 187
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 187
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> Attempt to read property "product_image_file" on null C:\xampp\htdocs\printcare\application\modules\product\views\product_form_view.php 187
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:04:25 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:08:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:08:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:08:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:08:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:08:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:08:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:08:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:08:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:08:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:08:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:08:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:08:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:08:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:08:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:08:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:08:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:08:40 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:08:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:08:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:08:40 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:08:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:08:40 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:08:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:08:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:08:40 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:08:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:08:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:08:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:08:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:08:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:08:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:08:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:08:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:08:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:08:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:08:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:08:57 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:08:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:08:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:08:57 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:08:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:08:57 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:08:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:08:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:08:57 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:09:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:09:01 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:09:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:09:01 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:09:01 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:09:01 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:09:01 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:09:20 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:10:14 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:10:15 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:10:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:10:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:10:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:10:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:10:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:10:38 --> Severity: error --> Exception: [] operator not supported for strings C:\xampp\htdocs\printcare\application\models\Common_model.php 2422
ERROR - 2022-08-01 13:10:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:10:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:10:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:10:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:10:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:10:41 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:10:41 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:10:47 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:10:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:10:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:10:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:10:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:10:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:10:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:10:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:10:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:10:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:10:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:10:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:10:57 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:10:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:10:57 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:10:57 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:11:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:11:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:11:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:11:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:11:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:11:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:11:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:11:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:11:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:11:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:11:33 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\printcare\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-08-01 13:11:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:11:41 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:11:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:11:41 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:11:41 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:11:41 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\printcare\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-08-01 13:11:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:11:45 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:11:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:11:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:11:45 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:11:45 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\printcare\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-08-01 13:12:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:12:05 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:12:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:12:05 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:12:05 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:12:05 --> Severity: 8192 --> Required parameter $repx follows optional parameter $resize C:\xampp\htdocs\printcare\application\libraries\mpdf\mpdf.php 1801
ERROR - 2022-08-01 13:12:05 --> Severity: 8192 --> Required parameter $repy follows optional parameter $resize C:\xampp\htdocs\printcare\application\libraries\mpdf\mpdf.php 0
ERROR - 2022-08-01 13:12:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\printcare\system\core\Exceptions.php:272) C:\xampp\htdocs\printcare\system\core\Common.php 573
ERROR - 2022-08-01 13:12:05 --> Severity: Compile Error --> Array and string offset access syntax with curly braces is no longer supported C:\xampp\htdocs\printcare\application\libraries\mpdf\mpdf.php 1984
ERROR - 2022-08-01 13:12:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:12:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:12:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:12:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:12:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> Undefined variable $supplier C:\xampp\htdocs\printcare\application\modules\supplier\views\supplier_form_view.php 16
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\supplier\views\supplier_form_view.php 16
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> Attempt to read property "supplier_name" on null C:\xampp\htdocs\printcare\application\modules\supplier\views\supplier_form_view.php 16
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> Undefined variable $supplier C:\xampp\htdocs\printcare\application\modules\supplier\views\supplier_form_view.php 24
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\printcare\application\modules\supplier\views\supplier_form_view.php 24
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> Attempt to read property "supplier_code" on null C:\xampp\htdocs\printcare\application\modules\supplier\views\supplier_form_view.php 24
ERROR - 2022-08-01 13:13:04 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:13:14 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:13:14 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:13:14 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:13:14 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:13:14 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:13:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:13:17 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:13:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:13:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:13:17 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:13:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:13:17 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:13:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:13:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:13:17 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:13:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:13:23 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:13:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:13:23 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:13:23 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:13:23 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:13:23 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:13:23 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:13:23 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:13:30 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:13:30 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:13:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:13:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:13:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:13:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:13:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:13:31 --> Severity: Warning --> Undefined array key "redirect_to" C:\xampp\htdocs\printcare\application\modules\supplier\controllers\Supplier.php 208
ERROR - 2022-08-01 13:13:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:13:31 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:13:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:13:31 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:13:31 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:13:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:13:34 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:13:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:13:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:13:34 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:13:34 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:13:34 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:13:34 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:13:34 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:13:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:13:43 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:13:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:13:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:13:43 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:13:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:13:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:13:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:13:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:13:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:13:56 --> Severity: Warning --> Undefined property: stdClass::$salutation_name C:\xampp\htdocs\printcare\application\modules\supplier\views\ajax_supplier_details_view.php 19
ERROR - 2022-08-01 13:14:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:14:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:14:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:14:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:14:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:14:11 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:14:11 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:14:11 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:14:11 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:14:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:14:13 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:14:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:14:13 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:14:13 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:14:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:14:17 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:14:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:14:17 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:14:17 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:14:17 --> Severity: Warning --> Undefined property: stdClass::$salutation_name C:\xampp\htdocs\printcare\application\modules\supplier\views\ajax_supplier_details_view.php 19
ERROR - 2022-08-01 13:14:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:14:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:14:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:14:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:14:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:14:35 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:14:35 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:14:35 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:14:35 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:17:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:17:03 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:17:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:17:03 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:17:03 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:17:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:17:11 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:17:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:17:11 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:17:11 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:17:11 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:17:11 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:17:11 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:17:11 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:17:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:17:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:17:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:17:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:17:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:17:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:17:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:17:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:17:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:17:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:17:24 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-08-01 13:17:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:17:27 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:17:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:17:27 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:17:27 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:17:27 --> Severity: Warning --> Undefined variable $sql C:\xampp\htdocs\printcare\application\models\Common_model.php 1860
ERROR - 2022-08-01 13:17:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:17:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:17:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:17:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:17:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:17:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:17:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:17:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:17:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:17:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> Undefined array key "audit_record" C:\xampp\htdocs\printcare\application\models\User_model.php 13
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> Undefined array key "ref_branch_id" C:\xampp\htdocs\printcare\application\models\User_model.php 14
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\printcare\application\models\User_model.php 17
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:17:56 --> Severity: Warning --> Undefined variable $pagination_block C:\xampp\htdocs\printcare\application\modules\user\views\user_list.php 134
ERROR - 2022-08-01 13:18:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:18:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:18:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:18:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:18:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:18:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:18:00 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:18:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:18:00 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:18:00 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:18:10 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:18:10 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:18:10 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:18:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:18:32 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:18:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:18:32 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:18:32 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:18:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:18:48 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:18:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:18:48 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:18:48 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:20:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:20:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:20:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:20:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:20:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:22:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:22:24 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:22:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:22:24 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:22:24 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:23:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:23:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:23:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:23:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:23:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:23:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:23:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:23:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:23:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:23:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:23:15 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:23:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:23:35 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:23:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:23:35 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:23:35 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:23:36 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:24:21 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:24:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:24:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:24:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:24:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:24:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:24:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:24:28 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:24:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:24:28 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:24:28 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:24:28 --> 404 Page Not Found: /index
ERROR - 2022-08-01 13:25:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:25:40 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:25:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:25:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:25:40 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:25:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:25:40 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:25:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:25:40 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:25:40 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:25:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:25:45 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:25:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:25:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:25:45 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:25:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 281
ERROR - 2022-08-01 13:25:46 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 293
ERROR - 2022-08-01 13:25:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 303
ERROR - 2022-08-01 13:25:46 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\drivers\Session_files_driver.php 94
ERROR - 2022-08-01 13:25:46 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\printcare\system\libraries\Session\Session.php 107
ERROR - 2022-08-01 13:25:46 --> 404 Page Not Found: /index
